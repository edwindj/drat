#' Chunked
#'
#' With chunked you can use dplyr chunkwise on text files
#'
#' @section Implemented dplyr verbs:
#'
#' @section Not implemented:
#'
#'
#' @docType package
#' @name chunked-package
#' @aliases select filter mutate dplyr-verbs
NULL
