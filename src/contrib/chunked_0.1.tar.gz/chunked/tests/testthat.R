library(testthat)
library(chunked)

test_check("chunked")
